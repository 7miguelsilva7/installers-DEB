#!/bin/bash
git pull
git add --all
git commit -m "update"
git push

