/opt/lampp/bin/mysqldump -u root simrede > tmp/simRede-simrede-backup.sql

/opt/lampp/bin/mysqldump -u root bitnami_moodle > tmp/simRede-moodle-backup.sql
